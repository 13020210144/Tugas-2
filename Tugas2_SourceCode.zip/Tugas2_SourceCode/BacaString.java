/*
 * Tanggal 21 Maret 2023
 * 
 * Nama: Wa Ode Nuraini Sari Bici
 * NIM: 13020210144
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class BacaString {
/**
* @param args
* @throws IOException
*/
public static void main(String[] args) throws IOException {
// TODO Auto-generated method stub
/* Kamus */
String str;
BufferedReader datAIn = new BufferedReader(new
InputStreamReader(System.in));
/* Program */
System.out.print ("\nBaca string dan Integer: \n");
System.out.print("masukkan sebuah string: ");
str= datAIn.readLine();
System.out.print ("String yang dibaca : "+ str);
}
}