/*
 * Tanggal 21 Maret 2023
 * 
 * Nama: Wa Ode Nuraini Sari Bici
 * NIM: 13020210144
 */
public class ForEver {
    /**
    * @param args
    */
    public static void main(String[] args) {
    // TODO Auto-generated method stub
    /* Program */
    System.out.println("Program akan looping, akhiri dengan ^c");
    while (true)
    { System.out.print ("Print satu baris.....\n");
    }
    }
}
