/*
 * Tanggal 21 Maret 2023
 * 
 * Nama: Wa Ode Nuraini Sari Bici
 * NIM: 13020210144
 */
/* Eksrpesi kondisional dengan boolean */
public class KasusBoolean {
    /**
    * @param args
    */
    public static void main(String[] args) {
    // TODO Auto-generated method stub
    /* Kamus */
    boolean bool;
    /* Algoritma */
    bool= false;
    if(bool) {
    System.out.print("true\n");
    } else
    System.out.print("false\n");
    if(!bool) {
    System.out.print("salah\n");
    } else
    System.out.print("benar\n");
    }
    }
    